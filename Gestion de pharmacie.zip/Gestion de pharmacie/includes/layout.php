<?php
require_once __DIR__ . '/../config/auth.php';

function page_start(string $title, string $active): void {
    $user = current_user();
    $flash = get_flash();
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?> - GestionPharma</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script defer src="assets/js/app.js"></script>
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <div class="sidebar-logo"><span>💊 GestionPharma</span></div>
        <nav class="sidebar-nav">
            <?php
            $items = [
                'dashboard' => ['dashboard.php', 'Tableau de bord'],
                'medicaments' => ['medicaments.php', 'Médicaments'],
                'ventes' => ['ventes.php', 'Ventes'],
                'fournisseurs' => ['fournisseurs.php', 'Fournisseurs'],
                'commandes' => ['commandes.php', 'Commandes'],
                'alertes' => ['alertes.php', 'Alertes'],
                'utilisateurs' => ['utilisateurs.php', 'Utilisateurs'],
            ];
            foreach ($items as $key => [$href, $label]) {
                $cls = $key === $active ? 'nav-item active' : 'nav-item';
                echo '<a class="' . $cls . '" href="' . $href . '"><span>' . $label . '</span></a>';
            }
            ?>
        </nav>
        <div class="sidebar-user">
            <div class="avatar"><?= strtoupper(substr(($user['prenom'] ?? 'A'), 0, 1)) ?></div>
            <div>
                <strong><?= htmlspecialchars(($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? '')) ?></strong>
                <small><?= htmlspecialchars($user['role'] ?? '') ?></small>
            </div>
            <a class="logout-link" href="logout.php" title="Déconnexion" aria-label="Déconnexion">⏻</a>
        </div>
    </aside>
    <main class="main-panel">
        <header class="topbar">
            <div>
                <h1><?= htmlspecialchars($title) ?></h1>
                <p>Interface professionnelle de suivi, de vente et de gestion du stock.</p>
            </div>
        </header>
        <section class="page-content">
            <?php if ($flash): ?>
                <div class="flash <?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['message']) ?></div>
            <?php endif; ?>
    <?php
}

function page_end(): void {
    ?>
        </section>
    </main>
</div>
</body>
</html>
    <?php
}
?>
