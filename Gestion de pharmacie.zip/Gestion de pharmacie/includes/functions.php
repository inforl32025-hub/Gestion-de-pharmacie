<?php
require_once __DIR__ . '/../config/database.php';

function fetch_all_users(PDO $pdo): array {
    $stmt = $pdo->query('SELECT * FROM utilisateurs ORDER BY id_utilisateur DESC');
    return $stmt->fetchAll();
}

function fetch_all_fournisseurs(PDO $pdo): array {
    $stmt = $pdo->query('SELECT * FROM fournisseurs ORDER BY nom ASC');
    return $stmt->fetchAll();
}

function fetch_all_medicaments(PDO $pdo): array {
    $sql = 'SELECT m.*, f.nom AS fournisseur_nom,
                   DATEDIFF(m.date_expiration, CURDATE()) AS jours_restants
            FROM medicaments m
            LEFT JOIN fournisseurs f ON f.id_fournisseur = m.id_fournisseur
            ORDER BY m.nom ASC';
    return $pdo->query($sql)->fetchAll();
}

function dashboard_stats(PDO $pdo): array {
    return [
        'medicaments' => (int) $pdo->query('SELECT COUNT(*) FROM medicaments')->fetchColumn(),
        'utilisateurs' => (int) $pdo->query('SELECT COUNT(*) FROM utilisateurs')->fetchColumn(),
        'fournisseurs' => (int) $pdo->query('SELECT COUNT(*) FROM fournisseurs')->fetchColumn(),
        'ventes_count' => (int) $pdo->query('SELECT COUNT(*) FROM ventes WHERE DATE(date_vente) = CURDATE()')->fetchColumn(),
        'alertes' => (int) $pdo->query("SELECT COUNT(*) FROM medicaments WHERE stock <= seuil_alerte OR date_expiration <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)")->fetchColumn(),
        'ventes_jour' => (float) $pdo->query("SELECT COALESCE(SUM(total_vente), 0) FROM ventes WHERE DATE(date_vente) = CURDATE()") ->fetchColumn(),
    ];
}

function recent_sales(PDO $pdo, int $limit = 8): array {
    $stmt = $pdo->prepare('SELECT v.*, COALESCE(p.nom, v.client_libre, "Client direct") AS client_nom
                           FROM ventes v
                           LEFT JOIN patients p ON p.id_patient = v.id_patient
                           ORDER BY v.id_vente DESC
                           LIMIT :lim');
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function stock_alerts(PDO $pdo): array {
    $stmt = $pdo->query('SELECT * FROM medicaments WHERE stock <= seuil_alerte ORDER BY stock ASC, nom ASC');
    return $stmt->fetchAll();
}

function expiring_alerts(PDO $pdo): array {
    $stmt = $pdo->query('SELECT *, DATEDIFF(date_expiration, CURDATE()) AS jours_restants
                         FROM medicaments
                         WHERE date_expiration IS NOT NULL AND date_expiration <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                         ORDER BY date_expiration ASC');
    return $stmt->fetchAll();
}

function commandes_list(PDO $pdo): array {
    $sql = 'SELECT c.*, f.nom AS fournisseur_nom
            FROM commandes c
            LEFT JOIN fournisseurs f ON f.id_fournisseur = c.id_fournisseur
            ORDER BY c.id_commande DESC';
    return $pdo->query($sql)->fetchAll();
}

function ventes_list(PDO $pdo): array {
    $sql = 'SELECT v.*, COALESCE(p.nom, v.client_libre, "Client direct") AS client_nom
            FROM ventes v
            LEFT JOIN patients p ON p.id_patient = v.id_patient
            ORDER BY v.id_vente DESC';
    return $pdo->query($sql)->fetchAll();
}

function ensure_activity_log_table(PDO $pdo): void {
    static $done = false;
    if ($done) {
        return;
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS journal_activites (
        id_activite INT AUTO_INCREMENT PRIMARY KEY,
        type_activite VARCHAR(100) NOT NULL,
        description VARCHAR(255) NOT NULL,
        utilisateur_nom VARCHAR(150) DEFAULT NULL,
        date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done = true;
}

function log_activity(PDO $pdo, string $type, string $description): void {
    ensure_activity_log_table($pdo);
    $user = function_exists('current_user') ? current_user() : null;
    $nom = null;
    if ($user) {
        $nom = trim(($user['prenom'] ?? '') . ' ' . ($user['nom'] ?? ''));
        $nom = $nom !== '' ? $nom : null;
    }
    $stmt = $pdo->prepare('INSERT INTO journal_activites (type_activite, description, utilisateur_nom) VALUES (?, ?, ?)');
    $stmt->execute([$type, $description, $nom]);
}

function recent_activities(PDO $pdo, int $limit = 10): array {
    ensure_activity_log_table($pdo);
    $stmt = $pdo->prepare('SELECT * FROM journal_activites ORDER BY id_activite DESC LIMIT :lim');
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}
?>
