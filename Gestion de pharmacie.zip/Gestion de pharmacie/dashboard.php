<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

$stats = dashboard_stats($pdo);
$stocks = stock_alerts($pdo);
$ventes = recent_sales($pdo);
$expirations = expiring_alerts($pdo);
$activities = recent_activities($pdo);

page_start('Tableau de bord', 'dashboard');
?>
<div class="stats-grid">
  <div class="stat-card"><div class="label">Médicaments</div><div class="value"><?= $stats['medicaments'] ?></div><div class="caption">Produits enregistrés</div></div>
  <div class="stat-card"><div class="label">Ventes du jour</div><div class="value"><?= number_format($stats['ventes_jour'], 0, ',', ' ') ?> DJF</div><div class="caption"><?= $stats['ventes_count'] ?> vente(s)</div></div>
  <div class="stat-card"><div class="label">Utilisateurs</div><div class="value"><?= $stats['utilisateurs'] ?></div><div class="caption">Comptes actifs</div></div>
  <div class="stat-card"><div class="label">Fournisseurs</div><div class="value"><?= $stats['fournisseurs'] ?></div><div class="caption">Partenaires enregistrés</div></div>
  <div class="stat-card"><div class="label">Alertes actives</div><div class="value"><?= $stats['alertes'] ?></div><div class="caption">Stock et expiration</div></div>
</div>
<div class="grid-2-equal">
  <div>
    <div class="card">
      <div class="card-header"><h3>Stock faible</h3></div>
      <div class="card-body">
        <?php if (!$stocks): ?><div class="empty">Aucune alerte de stock.</div><?php else: ?>
        <table>
          <thead><tr><th>Nom</th><th>Stock</th><th>Seuil</th></tr></thead>
          <tbody>
          <?php foreach ($stocks as $m): ?>
            <tr><td><?= htmlspecialchars($m['nom']) ?></td><td><span class="badge red"><?= (int) $m['stock'] ?></span></td><td><?= (int) $m['seuil_alerte'] ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Dernières ventes</h3></div>
      <div class="card-body">
        <table>
          <thead><tr><th>Date</th><th>Client</th><th>Type</th><th>Total</th></tr></thead>
          <tbody>
          <?php foreach ($ventes as $vente): ?>
            <tr>
              <td><?= htmlspecialchars($vente['date_vente']) ?></td>
              <td><?= htmlspecialchars($vente['client_nom']) ?></td>
              <td><span class="badge blue"><?= htmlspecialchars($vente['type_vente']) ?></span></td>
              <td><?= number_format($vente['total_vente'], 0, ',', ' ') ?> DJF</td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div>
    <div class="card panel-muted">
      <div class="card-header"><h3>Derniers changements</h3></div>
      <div class="card-body activity-list">
        <?php if (!$activities): ?>
          <div class="empty">Aucun changement récent.</div>
        <?php else: foreach ($activities as $activity): ?>
          <div class="activity-item">
            <strong><?= htmlspecialchars($activity['description']) ?></strong>
            <div class="small"><?= htmlspecialchars($activity['type_activite']) ?><?php if (!empty($activity['utilisateur_nom'])): ?> · <?= htmlspecialchars($activity['utilisateur_nom']) ?><?php endif; ?></div>
            <div class="small"><?= htmlspecialchars($activity['date_creation']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Expiration proche</h3></div>
      <div class="card-body kpi-list">
        <?php if (!$expirations): ?><div class="empty">Aucun médicament proche de la péremption.</div><?php else: foreach (array_slice($expirations, 0, 6) as $m): ?>
          <div class="alert-item">
            <strong><?= htmlspecialchars($m['nom']) ?></strong>
            <div class="small">Expire le <?= htmlspecialchars($m['date_expiration']) ?> · <?= (int)$m['jours_restants'] ?> jour(s)</div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<?php page_end(); ?>
