<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prenom = trim($_POST['prenom'] ?? '');
    $nom = trim($_POST['nom'] ?? '');
    $nom_pharmacie = trim($_POST['nom_pharmacie'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';
    $role = $_POST['role'] ?? 'pharmacien';

    if ($prenom === '' || $nom === '' || $email === '' || $mot_de_passe === '') {
        flash('error', 'Tous les champs obligatoires doivent être remplis.');
        header('Location: register.php');
        exit;
    }

    $check = $pdo->prepare('SELECT COUNT(*) FROM utilisateurs WHERE email = ?');
    $check->execute([$email]);
    if ((int) $check->fetchColumn() > 0) {
        flash('error', 'Cet email existe déjà.');
        header('Location: register.php');
        exit;
    }

    $stmt = $pdo->prepare('INSERT INTO utilisateurs (prenom, nom, nom_pharmacie, email, mot_de_passe, role) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$prenom, $nom, $nom_pharmacie, $email, password_hash($mot_de_passe, PASSWORD_DEFAULT), $role]);

    flash('success', 'Compte créé avec succès. Vous pouvez maintenant vous connecter.');
    header('Location: login.php');
    exit;
}
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inscription - GestionPharma</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">
  <div class="auth-card">
    <div class="brand"><div class="brand-icon">💊</div>GestionPharma</div>
    <h1>Inscription</h1>
    <p class="sub">Créez votre compte pharmacie.</p>
    <?php if ($flash): ?><div class="flash <?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['message']) ?></div><?php endif; ?>
    <form method="post">
      <div class="form-grid">
        <div class="form-group"><label>Prénom</label><input type="text" name="prenom" required></div>
        <div class="form-group"><label>Nom</label><input type="text" name="nom" required></div>
      </div>
      <div class="form-group"><label>Nom de la pharmacie</label><input type="text" name="nom_pharmacie"></div>
      <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
      <div class="form-group"><label>Mot de passe</label><input type="password" name="mot_de_passe" required></div>
      <div class="form-group"><label>Rôle</label>
        <select name="role">
          <option value="admin">Administrateur</option>
          <option value="pharmacien">Pharmacien</option>
        </select>
      </div>
      <button class="btn btn-primary w-100" type="submit">Créer le compte</button>
    </form>
    <div class="auth-links">Déjà un compte ? <a href="login.php">Se connecter</a></div>
  </div>
</body>
</html>
