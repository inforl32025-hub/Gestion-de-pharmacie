<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'save') {
        $id = (int) ($_POST['id_fournisseur'] ?? 0);
        $params = [trim($_POST['nom'] ?? ''), trim($_POST['contact'] ?? ''), trim($_POST['telephone'] ?? ''), trim($_POST['email'] ?? ''), trim($_POST['adresse'] ?? '')];
        if ($id > 0) {
            $params[] = $id;
            $pdo->prepare('UPDATE fournisseurs SET nom=?, contact=?, telephone=?, email=?, adresse=? WHERE id_fournisseur=?')->execute($params);
            log_activity($pdo, 'Fournisseurs', 'Fournisseur modifié : ' . trim($_POST['nom'] ?? ''));
            flash('success', 'Fournisseur modifié.');
        } else {
            $pdo->prepare('INSERT INTO fournisseurs (nom, contact, telephone, email, adresse) VALUES (?, ?, ?, ?, ?)')->execute($params);
            log_activity($pdo, 'Fournisseurs', 'Nouveau fournisseur ajouté : ' . trim($_POST['nom'] ?? ''));
            flash('success', 'Fournisseur ajouté.');
        }
    }
    if (($_POST['action'] ?? '') === 'delete_selected') {
        $ids = array_map('intval', $_POST['selected_ids'] ?? []);
        $ids = array_values(array_filter($ids));
        if (!$ids) {
            flash('warning', 'Veuillez cocher au moins un fournisseur.');
        } else {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $pdo->prepare("SELECT nom FROM fournisseurs WHERE id_fournisseur IN ($placeholders)");
            $stmt->execute($ids);
            $noms = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $pdo->prepare("DELETE FROM fournisseurs WHERE id_fournisseur IN ($placeholders)")->execute($ids);
            log_activity($pdo, 'Fournisseurs', count($ids) . ' fournisseur(s) supprimé(s) : ' . implode(', ', $noms));
            flash('success', count($ids) . ' fournisseur(s) supprimé(s).');
        }
    }
    header('Location: fournisseurs.php');
    exit;
}
$fournisseurs = fetch_all_fournisseurs($pdo);
$edit = null; if (isset($_GET['edit'])) { $stmt = $pdo->prepare('SELECT * FROM fournisseurs WHERE id_fournisseur=?'); $stmt->execute([(int) $_GET['edit']]); $edit = $stmt->fetch(); }
page_start('Fournisseurs', 'fournisseurs');
?>
<div class="page-actions"><div class="toolbar"><button class="btn btn-primary" type="button" data-modal-target="#fournisseur-modal">Ajouter un fournisseur</button><button class="btn btn-danger" type="submit" form="delete-fournisseurs-form" data-confirm="Supprimer les fournisseurs cochés ?">Supprimer la sélection</button></div></div>
<div id="fournisseur-modal" class="modal <?= $edit ? 'show' : '' ?>" data-close-url="fournisseurs.php">
  <div class="modal-panel">
    <div class="modal-header"><h3><?= $edit ? 'Modifier un fournisseur' : 'Ajouter un fournisseur' ?></h3><button class="modal-close" type="button" data-close-modal>&times;</button></div>
    <div class="modal-body">
      <form method="post">
        <input type="hidden" name="action" value="save"><input type="hidden" name="id_fournisseur" value="<?= (int)($edit['id_fournisseur'] ?? 0) ?>">
        <div class="form-grid"><div class="form-group"><label>Nom</label><input name="nom" required value="<?= htmlspecialchars($edit['nom'] ?? '') ?>"></div><div class="form-group"><label>Contact</label><input name="contact" value="<?= htmlspecialchars($edit['contact'] ?? '') ?>"></div></div>
        <div class="form-grid"><div class="form-group"><label>Téléphone</label><input name="telephone" value="<?= htmlspecialchars($edit['telephone'] ?? '') ?>"></div><div class="form-group"><label>Email</label><input type="email" name="email" value="<?= htmlspecialchars($edit['email'] ?? '') ?>"></div></div>
        <div class="form-group"><label>Adresse</label><textarea name="adresse"><?= htmlspecialchars($edit['adresse'] ?? '') ?></textarea></div>
        <div class="actions"><button class="btn btn-primary" type="submit">Enregistrer</button><button class="btn btn-secondary" type="reset">Vider</button></div>
      </form>
    </div>
  </div>
</div>
<div class="card"><div class="card-header"><h3>Liste des fournisseurs</h3></div><div class="card-body"><div class="helper-text">Double-clique sur une ligne cochée pour modifier le fournisseur sélectionné.</div><form method="post" id="delete-fournisseurs-form"><input type="hidden" name="action" value="delete_selected"><table><thead><tr><th><input class="bulk-check" type="checkbox" data-check-all></th><th>Nom</th><th>Contact</th><th>Téléphone</th><th>Email</th><th>Adresse</th></tr></thead><tbody><?php foreach ($fournisseurs as $f): ?><tr class="row-editable" data-edit-url="fournisseurs.php?edit=<?= $f['id_fournisseur'] ?>"><td><input class="row-selector bulk-check" type="checkbox" name="selected_ids[]" value="<?= $f['id_fournisseur'] ?>"></td><td><?= htmlspecialchars($f['nom']) ?></td><td><?= htmlspecialchars($f['contact']) ?></td><td><?= htmlspecialchars($f['telephone']) ?></td><td><?= htmlspecialchars($f['email']) ?></td><td><?= htmlspecialchars($f['adresse']) ?></td></tr><?php endforeach; ?></tbody></table></form></div></div>
<?php page_end(); ?>
