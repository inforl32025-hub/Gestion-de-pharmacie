DROP DATABASE IF EXISTS gestion_pharmacie;
CREATE DATABASE gestion_pharmacie CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_pharmacie;

CREATE TABLE utilisateurs (
  id_utilisateur INT AUTO_INCREMENT PRIMARY KEY,
  prenom VARCHAR(100) NOT NULL,
  nom VARCHAR(100) NOT NULL,
  nom_pharmacie VARCHAR(150) DEFAULT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  mot_de_passe VARCHAR(255) NOT NULL,
  role ENUM('admin','pharmacien') NOT NULL DEFAULT 'pharmacien',
  date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE fournisseurs (
  id_fournisseur INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  contact VARCHAR(100) DEFAULT NULL,
  telephone VARCHAR(50) DEFAULT NULL,
  email VARCHAR(150) DEFAULT NULL,
  adresse TEXT DEFAULT NULL,
  date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE medicaments (
  id_medicament INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(50) DEFAULT NULL,
  nom VARCHAR(150) NOT NULL,
  description TEXT DEFAULT NULL,
  categorie VARCHAR(100) DEFAULT 'Autres',
  prix_unitaire DECIMAL(10,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  seuil_alerte INT NOT NULL DEFAULT 10,
  date_ajout DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  date_expiration DATE DEFAULT NULL,
  id_fournisseur INT DEFAULT NULL,
  CONSTRAINT fk_medicament_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES fournisseurs(id_fournisseur) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE patients (
  id_patient INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(150) NOT NULL,
  date_naissance DATE DEFAULT NULL,
  contact VARCHAR(50) DEFAULT NULL,
  date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE ventes (
  id_vente INT AUTO_INCREMENT PRIMARY KEY,
  id_patient INT DEFAULT NULL,
  client_libre VARCHAR(150) DEFAULT NULL,
  type_vente ENUM('direct','ordonnance') NOT NULL DEFAULT 'direct',
  reference_ordonnance VARCHAR(100) DEFAULT NULL,
  date_vente DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_vente DECIMAL(10,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_vente_patient FOREIGN KEY (id_patient) REFERENCES patients(id_patient) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE vente_details (
  id_detail INT AUTO_INCREMENT PRIMARY KEY,
  id_vente INT NOT NULL,
  id_medicament INT NOT NULL,
  quantite INT NOT NULL,
  prix_unitaire DECIMAL(10,2) NOT NULL,
  sous_total DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_detail_vente FOREIGN KEY (id_vente) REFERENCES ventes(id_vente) ON DELETE CASCADE,
  CONSTRAINT fk_detail_medicament FOREIGN KEY (id_medicament) REFERENCES medicaments(id_medicament) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE commandes (
  id_commande INT AUTO_INCREMENT PRIMARY KEY,
  id_fournisseur INT DEFAULT NULL,
  date_commande DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  statut ENUM('en cours','livree','annulee') NOT NULL DEFAULT 'en cours',
  notes TEXT DEFAULT NULL,
  montant_total DECIMAL(10,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_commande_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES fournisseurs(id_fournisseur) ON DELETE SET NULL
) ENGINE=InnoDB;



CREATE TABLE journal_activites (
  id_activite INT AUTO_INCREMENT PRIMARY KEY,
  type_activite VARCHAR(100) NOT NULL,
  description VARCHAR(255) NOT NULL,
  utilisateur_nom VARCHAR(150) DEFAULT NULL,
  date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE alertes (
  id_alerte INT AUTO_INCREMENT PRIMARY KEY,
  id_medicament INT DEFAULT NULL,
  type_alerte ENUM('bientot perime','perime','stock faible') DEFAULT NULL,
  message TEXT,
  date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
  jours_restants INT DEFAULT NULL,
  CONSTRAINT fk_alerte_medicament FOREIGN KEY (id_medicament) REFERENCES medicaments(id_medicament) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO utilisateurs (prenom, nom, nom_pharmacie, email, mot_de_passe, role) VALUES
('Admin', 'Principal', 'GestionPharma Centrale', 'admin@gestionpharma.com', '$2y$10$6Cz0j4xXJgSOf9jeJxE0duXHCMJLZ/HXXIQK5vCk1vZ1tcHTTX3eK', 'admin');

INSERT INTO fournisseurs (nom, contact, telephone, email, adresse) VALUES
('MedSupply Djibouti', 'Hassan Aden', '+25377001122', 'contact@medsupply.dj', 'Zone Industrielle, Djibouti'),
('PharmaDistrib', 'Amina Warsame', '+25377334455', 'amina@pharmadistrib.dj', 'Rue du Commerce 14, Djibouti');

INSERT INTO medicaments (code, nom, description, categorie, prix_unitaire, stock, seuil_alerte, date_expiration, id_fournisseur) VALUES
('MED001', 'Amoxicilline 500mg', 'Antibiotique à large spectre', 'Antibiotiques', 850, 45, 20, '2026-08-15', 1),
('MED002', 'Paracétamol 1g', 'Antidouleur et antipyrétique', 'Antalgiques', 350, 8, 30, '2026-06-20', 1),
('MED003', 'Ibuprofène 400mg', 'Anti-inflammatoire non stéroïdien', 'Anti-inflammatoires', 600, 60, 25, '2026-07-30', 2);


INSERT INTO journal_activites (type_activite, description, utilisateur_nom) VALUES
('Utilisateurs', 'Nouveau compte créé : Admin Principal', 'Système'),
('Médicaments', 'Nouveau médicament ajouté : Amoxicilline 500mg', 'Système'),
('Ventes', 'Vente enregistrée pour Client direct - Paracétamol 1g', 'Système');
