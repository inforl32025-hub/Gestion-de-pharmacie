<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'save') {
        $id = (int) ($_POST['id_medicament'] ?? 0);
        $params = [
            trim($_POST['nom'] ?? ''),
            trim($_POST['description'] ?? ''),
            (float) ($_POST['prix_unitaire'] ?? 0),
            (int) ($_POST['stock'] ?? 0),
            $_POST['date_expiration'] ?: null,
            (int) ($_POST['id_fournisseur'] ?? 0) ?: null,
            trim($_POST['categorie'] ?? 'Autres'),
            trim($_POST['code'] ?? ''),
            (int) ($_POST['seuil_alerte'] ?? 0),
        ];
        if ($id > 0) {
            $sql = 'UPDATE medicaments SET nom=?, description=?, prix_unitaire=?, stock=?, date_expiration=?, id_fournisseur=?, categorie=?, code=?, seuil_alerte=? WHERE id_medicament=?';
            $params[] = $id;
            $pdo->prepare($sql)->execute($params);
            log_activity($pdo, 'Médicaments', 'Médicament modifié : ' . trim($_POST['nom'] ?? ''));
            flash('success', 'Médicament modifié avec succès.');
        } else {
            $sql = 'INSERT INTO medicaments (nom, description, prix_unitaire, stock, date_expiration, id_fournisseur, categorie, code, seuil_alerte) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
            $pdo->prepare($sql)->execute($params);
            log_activity($pdo, 'Médicaments', 'Nouveau médicament ajouté : ' . trim($_POST['nom'] ?? ''));
            flash('success', 'Médicament ajouté avec succès.');
        }
    }
    if (($_POST['action'] ?? '') === 'delete_selected') {
        $ids = array_map('intval', $_POST['selected_ids'] ?? []);
        $ids = array_values(array_filter($ids));
        if (!$ids) {
            flash('warning', 'Veuillez cocher au moins un médicament.');
        } else {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $pdo->prepare("SELECT nom FROM medicaments WHERE id_medicament IN ($placeholders)");
            $stmt->execute($ids);
            $noms = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $pdo->prepare("DELETE FROM medicaments WHERE id_medicament IN ($placeholders)")->execute($ids);
            log_activity($pdo, 'Médicaments', count($ids) . ' médicament(s) supprimé(s) : ' . implode(', ', $noms));
            flash('success', count($ids) . ' médicament(s) supprimé(s).');
        }
    }
    header('Location: medicaments.php');
    exit;
}

$edit = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM medicaments WHERE id_medicament=?');
    $stmt->execute([(int) $_GET['edit']]);
    $edit = $stmt->fetch();
}

$search = trim($_GET['search'] ?? '');
$filterNom = trim($_GET['nom'] ?? '');
$filterCode = trim($_GET['code'] ?? '');
$filterCategorie = trim($_GET['categorie'] ?? '');
$filterFournisseur = (int) ($_GET['fournisseur'] ?? 0);

$sql = 'SELECT m.*, f.nom AS fournisseur_nom FROM medicaments m LEFT JOIN fournisseurs f ON f.id_fournisseur = m.id_fournisseur WHERE 1=1';
$params = [];
if ($search !== '') { $sql .= ' AND (m.nom LIKE ? OR m.code LIKE ? OR m.categorie LIKE ? OR f.nom LIKE ?)'; $like = "%$search%"; array_push($params, $like, $like, $like, $like); }
if ($filterNom !== '') { $sql .= ' AND m.nom LIKE ?'; $params[] = "%$filterNom%"; }
if ($filterCode !== '') { $sql .= ' AND m.code LIKE ?'; $params[] = "%$filterCode%"; }
if ($filterCategorie !== '') { $sql .= ' AND m.categorie LIKE ?'; $params[] = "%$filterCategorie%"; }
if ($filterFournisseur > 0) { $sql .= ' AND m.id_fournisseur = ?'; $params[] = $filterFournisseur; }
$sql .= ' ORDER BY m.nom ASC';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $medicaments = $stmt->fetchAll();
$fournisseurs = fetch_all_fournisseurs($pdo);

page_start('Médicaments', 'medicaments');
?>
<div class="page-actions">
  <div class="toolbar">
    <button class="btn btn-primary" type="button" data-modal-target="#medicament-modal">Ajouter un médicament</button>
    <button class="btn btn-danger" type="submit" form="delete-medicaments-form" data-confirm="Supprimer les médicaments cochés ?">Supprimer la sélection</button>
  </div>
</div>
<div id="medicament-modal" class="modal <?= $edit ? 'show' : '' ?>" data-close-url="medicaments.php">
  <div class="modal-panel">
    <div class="modal-header">
      <h3><?= $edit ? 'Modifier un médicament' : 'Ajouter un médicament' ?></h3>
      <button class="modal-close" type="button" data-close-modal>&times;</button>
    </div>
    <div class="modal-body">
      <form method="post">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id_medicament" value="<?= (int)($edit['id_medicament'] ?? 0) ?>">
        <div class="form-grid">
          <div class="form-group"><label>Code</label><input name="code" value="<?= htmlspecialchars($edit['code'] ?? '') ?>"></div>
          <div class="form-group"><label>Nom</label><input name="nom" required value="<?= htmlspecialchars($edit['nom'] ?? '') ?>"></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label>Catégorie</label><input name="categorie" value="<?= htmlspecialchars($edit['categorie'] ?? 'Autres') ?>"></div>
          <div class="form-group"><label>Fournisseur</label><select name="id_fournisseur"><option value="">Choisir</option><?php foreach($fournisseurs as $f): ?><option value="<?= $f['id_fournisseur'] ?>" <?= (($edit['id_fournisseur'] ?? '') == $f['id_fournisseur']) ? 'selected' : '' ?>><?= htmlspecialchars($f['nom']) ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label>Prix unitaire</label><input type="number" step="0.01" name="prix_unitaire" required value="<?= htmlspecialchars($edit['prix_unitaire'] ?? '') ?>"></div>
          <div class="form-group"><label>Stock</label><input type="number" name="stock" required value="<?= htmlspecialchars($edit['stock'] ?? 0) ?>"></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label>Seuil d'alerte</label><input type="number" name="seuil_alerte" value="<?= htmlspecialchars($edit['seuil_alerte'] ?? 10) ?>"></div>
          <div class="form-group"><label>Date d'expiration</label><input type="date" name="date_expiration" value="<?= htmlspecialchars($edit['date_expiration'] ?? '') ?>"></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description"><?= htmlspecialchars($edit['description'] ?? '') ?></textarea></div>
        <div class="actions"><button class="btn btn-primary" type="submit">Enregistrer</button><button class="btn btn-secondary" type="reset">Vider</button></div>
      </form>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header"><h3>Liste des médicaments</h3></div>
  <div class="card-body">
    <form method="get">
      <div class="search-row"><input type="text" name="search" placeholder="Rechercher un médicament" value="<?= htmlspecialchars($search) ?>"><button class="btn btn-secondary" type="submit">Rechercher</button><a class="btn btn-secondary" href="medicaments.php">Réinitialiser</a></div>
      <div class="filter-grid">
        <div class="form-group"><label>Filtrer par nom</label><input type="text" name="nom" value="<?= htmlspecialchars($filterNom) ?>"></div>
        <div class="form-group"><label>Filtrer par code</label><input type="text" name="code" value="<?= htmlspecialchars($filterCode) ?>"></div>
        <div class="form-group"><label>Filtrer par catégorie</label><input type="text" name="categorie" value="<?= htmlspecialchars($filterCategorie) ?>"></div>
        <div class="form-group"><label>Filtrer par fournisseur</label><select name="fournisseur"><option value="">Tous</option><?php foreach($fournisseurs as $f): ?><option value="<?= $f['id_fournisseur'] ?>" <?= $filterFournisseur === (int)$f['id_fournisseur'] ? 'selected' : '' ?>><?= htmlspecialchars($f['nom']) ?></option><?php endforeach; ?></select></div>
      </div>
    </form>
    <div class="helper-text">Double-clique sur une ligne cochée pour modifier le médicament sélectionné.</div>
    <form method="post" id="delete-medicaments-form">
      <input type="hidden" name="action" value="delete_selected">
      <table>
        <thead><tr><th><input class="bulk-check" type="checkbox" data-check-all></th><th>Code</th><th>Nom</th><th>Catégorie</th><th>Stock</th><th>Prix</th><th>Fournisseur</th></tr></thead>
        <tbody>
        <?php foreach ($medicaments as $m): ?>
          <tr class="row-editable" data-edit-url="medicaments.php?edit=<?= $m['id_medicament'] ?>">
            <td><input class="row-selector bulk-check" type="checkbox" name="selected_ids[]" value="<?= $m['id_medicament'] ?>"></td>
            <td><?= htmlspecialchars($m['code']) ?></td>
            <td><?= htmlspecialchars($m['nom']) ?></td>
            <td><?= htmlspecialchars($m['categorie']) ?></td>
            <td><span class="badge <?= $m['stock'] <= $m['seuil_alerte'] ? 'red' : 'green' ?>"><?= (int)$m['stock'] ?></span></td>
            <td><?= number_format($m['prix_unitaire'], 0, ',', ' ') ?> DJF</td>
            <td><?= htmlspecialchars($m['fournisseur_nom'] ?? '-') ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </form>
  </div>
</div>
<?php page_end(); ?>
