<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM utilisateurs WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($mot_de_passe, $user['mot_de_passe'])) {
        login_user($user);
        flash('success', 'Connexion réussie.');
        header('Location: dashboard.php');
        exit;
    }

    flash('error', 'Email ou mot de passe incorrect.');
    header('Location: login.php');
    exit;
}
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Connexion - GestionPharma</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    .auth-page {
      position: relative;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .auth-bg {
      position: fixed;
      inset: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: 0;
    }
    .auth-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.45);
      z-index: 1;
    }
    .auth-card {
      position: relative;
      z-index: 2;
    }
  </style>
</head>
<body class="auth-page">

  <!-- Image de fond -->
  <img
    class="auth-bg"
    src="https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=1600&q=80"
    alt=""
  >
  <!-- Voile sombre pour lisibilité -->
  <div class="auth-overlay"></div>

  <div class="auth-card">
    <div class="brand"><div class="brand-icon">💊</div>GestionPharma</div>
    <h1>Connexion</h1>
    <p class="sub">Accédez à votre espace de gestion.</p>
    <?php if ($flash): ?>
      <div class="flash <?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['message']) ?></div>
    <?php endif; ?>
    <form method="post" action="login.php">
      <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
      <div class="form-group"><label>Mot de passe</label><input type="password" name="mot_de_passe" required></div>
      <button class="btn btn-primary w-100" type="submit">Se connecter</button>
    </form>
  </div>

</body>
</html>