document.addEventListener('click', function (event) {
  const confirmTrigger = event.target.closest('[data-confirm]');
  if (confirmTrigger) {
    if (!confirm(confirmTrigger.getAttribute('data-confirm'))) {
      event.preventDefault();
      return;
    }
  }

  const modalButton = event.target.closest('[data-modal-target]');
  if (modalButton) {
    const target = document.querySelector(modalButton.getAttribute('data-modal-target'));
    if (target) {
      target.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    return;
  }

  const closeButton = event.target.closest('[data-close-modal]');
  if (closeButton) {
    const modal = closeButton.closest('.modal');
    if (modal) {
      modal.classList.remove('show');
      document.body.style.overflow = '';
      const closeUrl = modal.getAttribute('data-close-url');
      if (closeUrl) {
        window.location.href = closeUrl;
      }
    }
    return;
  }

  if (event.target.matches('.modal')) {
    event.target.classList.remove('show');
    document.body.style.overflow = '';
    const closeUrl = event.target.getAttribute('data-close-url');
    if (closeUrl) {
      window.location.href = closeUrl;
    }
    return;
  }

  if (event.target.matches('[data-check-all]')) {
    const table = event.target.closest('table');
    if (!table) return;
    table.querySelectorAll('tbody .row-selector').forEach(function (checkbox) {
      checkbox.checked = event.target.checked;
    });
  }
});

document.addEventListener('dblclick', function (event) {
  const row = event.target.closest('tr[data-edit-url]');
  if (!row) return;
  const checkbox = row.querySelector('.row-selector');
  if (checkbox && checkbox.checked) {
    window.location.href = row.getAttribute('data-edit-url');
  }
});

document.addEventListener('keydown', function (event) {
  if (event.key !== 'Escape') return;
  document.querySelectorAll('.modal.show').forEach(function (modal) {
    modal.classList.remove('show');
    const closeUrl = modal.getAttribute('data-close-url');
    if (closeUrl) {
      window.location.href = closeUrl;
    }
  });
  document.body.style.overflow = '';
});

document.addEventListener('DOMContentLoaded', function () {
  if (document.querySelector('.modal.show')) {
    document.body.style.overflow = 'hidden';
  }
});
