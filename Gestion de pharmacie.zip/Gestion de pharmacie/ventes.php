<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'save') {
        $medicament_id = (int) ($_POST['id_medicament'] ?? 0);
        $quantite = max(1, (int) ($_POST['quantite'] ?? 1));
        $stmt = $pdo->prepare('SELECT * FROM medicaments WHERE id_medicament=?');
        $stmt->execute([$medicament_id]);
        $medicament = $stmt->fetch();
        if (!$medicament) { flash('error', 'Médicament introuvable.'); header('Location: ventes.php'); exit; }
        if ((int) $medicament['stock'] < $quantite) { flash('error', 'Stock insuffisant pour cette vente.'); header('Location: ventes.php'); exit; }
        $client_libre = trim($_POST['client_libre'] ?? '');
        $type_vente = $_POST['type_vente'] ?? 'direct';
        $reference_ordonnance = trim($_POST['reference_ordonnance'] ?? '');
        $total = $quantite * (float) $medicament['prix_unitaire'];
        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO ventes (date_vente, client_libre, type_vente, reference_ordonnance, total_vente) VALUES (NOW(), ?, ?, ?, ?)')->execute([$client_libre, $type_vente, $reference_ordonnance, $total]);
            $venteId = (int) $pdo->lastInsertId();
            $pdo->prepare('INSERT INTO vente_details (id_vente, id_medicament, quantite, prix_unitaire, sous_total) VALUES (?, ?, ?, ?, ?)')->execute([$venteId, $medicament_id, $quantite, $medicament['prix_unitaire'], $total]);
            $pdo->prepare('UPDATE medicaments SET stock = stock - ? WHERE id_medicament = ?')->execute([$quantite, $medicament_id]);
            $pdo->commit();
            log_activity($pdo, 'Ventes', 'Vente enregistrée pour ' . ($client_libre !== '' ? $client_libre : 'Client direct') . ' - ' . $medicament['nom']);
            flash('success', 'Vente enregistrée et stock mis à jour.');
        } catch (Throwable $e) {
            $pdo->rollBack();
            flash('error', "Erreur lors de l'enregistrement de la vente.");
        }
    }
    if (($_POST['action'] ?? '') === 'delete_selected') {
        $ids = array_map('intval', $_POST['selected_ids'] ?? []);
        $ids = array_values(array_filter($ids));
        if (!$ids) {
            flash('warning', 'Veuillez cocher au moins une vente.');
        } else {
            $pdo->beginTransaction();
            try {
                foreach ($ids as $idVente) {
                    $venteStmt = $pdo->prepare('SELECT id_vente, COALESCE(client_libre, "Client direct") AS client_nom FROM ventes WHERE id_vente=?');
                    $venteStmt->execute([$idVente]);
                    $vente = $venteStmt->fetch();
                    $details = $pdo->prepare('SELECT * FROM vente_details WHERE id_vente=?');
                    $details->execute([$idVente]);
                    foreach ($details->fetchAll() as $detail) {
                        $pdo->prepare('UPDATE medicaments SET stock = stock + ? WHERE id_medicament=?')->execute([$detail['quantite'], $detail['id_medicament']]);
                    }
                    $pdo->prepare('DELETE FROM vente_details WHERE id_vente=?')->execute([$idVente]);
                    $pdo->prepare('DELETE FROM ventes WHERE id_vente=?')->execute([$idVente]);
                    log_activity($pdo, 'Ventes', 'Vente supprimée : ' . ($vente['client_nom'] ?? 'Client direct'));
                }
                $pdo->commit();
                flash('success', count($ids) . ' vente(s) supprimée(s) et stock restauré.');
            } catch (Throwable $e) {
                $pdo->rollBack();
                flash('error', 'Impossible de supprimer la sélection.');
            }
        }
    }
    header('Location: ventes.php');
    exit;
}
$medicaments = fetch_all_medicaments($pdo);
$search = trim($_GET['search'] ?? '');
$filterClient = trim($_GET['client'] ?? '');
$filterType = trim($_GET['type'] ?? '');
$sql = 'SELECT v.*, COALESCE(p.nom, v.client_libre, "Client direct") AS client_nom FROM ventes v LEFT JOIN patients p ON p.id_patient = v.id_patient WHERE 1=1';
$params=[];
if($search!==''){ $sql .= ' AND (COALESCE(p.nom, v.client_libre, "Client direct") LIKE ? OR v.type_vente LIKE ? OR v.reference_ordonnance LIKE ?)'; $like="%$search%"; array_push($params,$like,$like,$like);} 
if($filterClient!==''){ $sql .= ' AND COALESCE(p.nom, v.client_libre, "Client direct") LIKE ?'; $params[]="%$filterClient%"; }
if($filterType!==''){ $sql .= ' AND v.type_vente = ?'; $params[]=$filterType; }
$sql .= ' ORDER BY v.id_vente DESC';
$stmt=$pdo->prepare($sql); $stmt->execute($params); $ventes=$stmt->fetchAll();
page_start('Ventes', 'ventes');
?>
<div class="page-actions">
  <div class="toolbar">
    <button class="btn btn-primary" type="button" data-modal-target="#vente-modal">Créer une vente</button>
    <button class="btn btn-danger" type="submit" form="delete-ventes-form" data-confirm="Supprimer les ventes cochées ?">Supprimer la sélection</button>
  </div>
</div>
<div id="vente-modal" class="modal" data-close-url="ventes.php">
  <div class="modal-panel">
    <div class="modal-header"><h3>Créer une vente</h3><button class="modal-close" type="button" data-close-modal>&times;</button></div>
    <div class="modal-body">
      <form method="post">
        <input type="hidden" name="action" value="save">
        <div class="form-grid">
          <div class="form-group"><label>Client</label><input name="client_libre"></div>
          <div class="form-group"><label>Type de vente</label><select name="type_vente"><option value="direct">Directe</option><option value="ordonnance">Ordonnance</option></select></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label>Référence ordonnance</label><input name="reference_ordonnance"></div>
          <div class="form-group"><label>Médicament</label><select name="id_medicament"><?php foreach($medicaments as $m): ?><option value="<?= $m['id_medicament'] ?>"><?= htmlspecialchars($m['nom']) ?> (stock: <?= (int)$m['stock'] ?>)</option><?php endforeach; ?></select></div>
        </div>
        <div class="form-group"><label>Quantité</label><input type="number" min="1" name="quantite" value="1"></div>
        <button class="btn btn-primary" type="submit">Valider la vente</button>
      </form>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-header"><h3>Historique des ventes</h3></div>
  <div class="card-body">
    <form method="get">
      <div class="search-row"><input type="text" name="search" placeholder="Rechercher une vente" value="<?= htmlspecialchars($search) ?>"><button class="btn btn-secondary" type="submit">Rechercher</button><a class="btn btn-secondary" href="ventes.php">Réinitialiser</a></div>
      <div class="filter-grid" style="grid-template-columns:repeat(2,minmax(160px,1fr));max-width:560px;">
        <div class="form-group"><label>Filtrer par client</label><input type="text" name="client" value="<?= htmlspecialchars($filterClient) ?>"></div>
        <div class="form-group"><label>Filtrer par type</label><select name="type"><option value="">Tous</option><option value="direct" <?= $filterType==='direct' ? 'selected' : '' ?>>Directe</option><option value="ordonnance" <?= $filterType==='ordonnance' ? 'selected' : '' ?>>Ordonnance</option></select></div>
      </div>
    </form>
    <form method="post" id="delete-ventes-form">
      <input type="hidden" name="action" value="delete_selected">
      <table>
        <thead><tr><th><input class="bulk-check" type="checkbox" data-check-all></th><th>Date</th><th>Client</th><th>Type</th><th>Total</th></tr></thead>
        <tbody><?php foreach($ventes as $v): ?><tr><td><input class="row-selector bulk-check" type="checkbox" name="selected_ids[]" value="<?= $v['id_vente'] ?>"></td><td><?= htmlspecialchars($v['date_vente']) ?></td><td><?= htmlspecialchars($v['client_nom']) ?></td><td><span class="badge blue"><?= htmlspecialchars($v['type_vente']) ?></span></td><td><?= number_format($v['total_vente'],0,',',' ') ?> DJF</td></tr><?php endforeach; ?></tbody>
      </table>
    </form>
  </div>
</div>
<?php page_end(); ?>
