<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

$stock = stock_alerts($pdo);
$expirations = expiring_alerts($pdo);
$commandes = array_filter(commandes_list($pdo), fn($row) => $row['statut'] === 'en cours');
page_start('Alertes', 'alertes');
?>
<div class="stats-grid">
  <div class="stat-card"><div>Stock faible</div><div class="value"><?= count($stock) ?></div></div>
  <div class="stat-card"><div>Expiration ≤ 30 jours</div><div class="value"><?= count($expirations) ?></div></div>
  <div class="stat-card"><div>Commandes en cours</div><div class="value"><?= count($commandes) ?></div></div>
  <div class="stat-card"><div>Alertes totales</div><div class="value"><?= count($stock) + count($expirations) + count($commandes) ?></div></div>
</div>
<div class="grid-2">
  <div class="card"><div class="card-header"><h3>Stock faible</h3></div><div class="card-body kpi-list"><?php if(!$stock): ?><div class="empty">Aucune alerte.</div><?php else: foreach($stock as $m): ?><div class="alert-item"><strong><?= htmlspecialchars($m['nom']) ?></strong><div class="small">Stock actuel: <?= (int)$m['stock'] ?> | Seuil: <?= (int)$m['seuil_alerte'] ?></div></div><?php endforeach; endif; ?></div></div>
  <div class="card"><div class="card-header"><h3>Péremption proche</h3></div><div class="card-body kpi-list"><?php if(!$expirations): ?><div class="empty">Aucune alerte.</div><?php else: foreach($expirations as $m): ?><div class="alert-item"><strong><?= htmlspecialchars($m['nom']) ?></strong><div class="small">Expiration: <?= htmlspecialchars($m['date_expiration']) ?> | <?= (int)$m['jours_restants'] ?> jour(s)</div></div><?php endforeach; endif; ?></div></div>
</div>
<div class="card"><div class="card-header"><h3>Commandes à suivre</h3></div><div class="card-body kpi-list"><?php if(!$commandes): ?><div class="empty">Aucune commande en cours.</div><?php else: foreach($commandes as $c): ?><div class="alert-item"><strong><?= htmlspecialchars($c['fournisseur_nom']) ?></strong><div class="small">Commande #<?= (int)$c['id_commande'] ?> | Montant: <?= number_format($c['montant_total'],0,',',' ') ?> DJF</div></div><?php endforeach; endif; ?></div></div>
<?php page_end(); ?>
