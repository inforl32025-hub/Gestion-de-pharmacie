<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'save') {
        $id = (int) ($_POST['id_commande'] ?? 0);
        $params = [(int) ($_POST['id_fournisseur'] ?? 0), $_POST['date_commande'] ? date('Y-m-d H:i:s', strtotime($_POST['date_commande'])) : date('Y-m-d H:i:s'), $_POST['statut'] ?? 'en cours', trim($_POST['notes'] ?? ''), (float) ($_POST['montant_total'] ?? 0)];
        if ($id > 0) {
            $params[] = $id;
            $pdo->prepare('UPDATE commandes SET id_fournisseur=?, date_commande=?, statut=?, notes=?, montant_total=? WHERE id_commande=?')->execute($params);
            log_activity($pdo, 'Commandes', 'Commande modifiée.');
            flash('success', 'Commande modifiée.');
        } else {
            $pdo->prepare('INSERT INTO commandes (id_fournisseur, date_commande, statut, notes, montant_total) VALUES (?, ?, ?, ?, ?)')->execute($params);
            log_activity($pdo, 'Commandes', 'Nouvelle commande créée.');
            flash('success', 'Commande ajoutée.');
        }
    }
    if (($_POST['action'] ?? '') === 'delete_selected') {
        $ids = array_map('intval', $_POST['selected_ids'] ?? []);
        $ids = array_values(array_filter($ids));
        if (!$ids) {
            flash('warning', 'Veuillez cocher au moins une commande.');
        } else {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $pdo->prepare("DELETE FROM commandes WHERE id_commande IN ($placeholders)")->execute($ids);
            log_activity($pdo, 'Commandes', count($ids) . ' commande(s) supprimée(s).');
            flash('success', count($ids) . ' commande(s) supprimée(s).');
        }
    }
    header('Location: commandes.php');
    exit;
}
$commandes = commandes_list($pdo); $fournisseurs = fetch_all_fournisseurs($pdo); $edit = null; if (isset($_GET['edit'])) { $stmt = $pdo->prepare('SELECT * FROM commandes WHERE id_commande=?'); $stmt->execute([(int) $_GET['edit']]); $edit = $stmt->fetch(); }
page_start('Commandes', 'commandes');
?>
<div class="page-actions"><div class="toolbar"><button class="btn btn-primary" type="button" data-modal-target="#commande-modal">Créer une commande</button><button class="btn btn-danger" type="submit" form="delete-commandes-form" data-confirm="Supprimer les commandes cochées ?">Supprimer la sélection</button></div></div>
<div id="commande-modal" class="modal <?= $edit ? 'show' : '' ?>" data-close-url="commandes.php">
  <div class="modal-panel">
    <div class="modal-header"><h3><?= $edit ? 'Modifier une commande' : 'Créer une commande' ?></h3><button class="modal-close" type="button" data-close-modal>&times;</button></div>
    <div class="modal-body">
      <form method="post"><input type="hidden" name="action" value="save"><input type="hidden" name="id_commande" value="<?= (int)($edit['id_commande'] ?? 0) ?>">
        <div class="form-grid"><div class="form-group"><label>Fournisseur</label><select name="id_fournisseur"><?php foreach($fournisseurs as $f): ?><option value="<?= $f['id_fournisseur'] ?>" <?= (($edit['id_fournisseur'] ?? '')==$f['id_fournisseur'])?'selected':'' ?>><?= htmlspecialchars($f['nom']) ?></option><?php endforeach; ?></select></div><div class="form-group"><label>Date commande</label><input type="datetime-local" name="date_commande" value="<?= isset($edit['date_commande']) ? date('Y-m-d\TH:i', strtotime($edit['date_commande'])) : date('Y-m-d\TH:i') ?>"></div></div>
        <div class="form-grid"><div class="form-group"><label>Statut</label><select name="statut"><option value="en cours" <?= (($edit['statut'] ?? '')==='en cours')?'selected':'' ?>>En cours</option><option value="livree" <?= (($edit['statut'] ?? '')==='livree')?'selected':'' ?>>Livrée</option><option value="annulee" <?= (($edit['statut'] ?? '')==='annulee')?'selected':'' ?>>Annulée</option></select></div><div class="form-group"><label>Montant total</label><input type="number" step="0.01" name="montant_total" value="<?= htmlspecialchars($edit['montant_total'] ?? 0) ?>"></div></div>
        <div class="form-group"><label>Notes</label><textarea name="notes"><?= htmlspecialchars($edit['notes'] ?? '') ?></textarea></div>
        <button class="btn btn-primary" type="submit">Enregistrer</button>
      </form>
    </div>
  </div>
</div>
<div class="card"><div class="card-header"><h3>Liste des commandes</h3></div><div class="card-body"><div class="helper-text">Double-clique sur une ligne cochée pour modifier la commande sélectionnée.</div><form method="post" id="delete-commandes-form"><input type="hidden" name="action" value="delete_selected"><table><thead><tr><th><input class="bulk-check" type="checkbox" data-check-all></th><th>Date</th><th>Fournisseur</th><th>Statut</th><th>Montant</th></tr></thead><tbody><?php foreach($commandes as $c): ?><tr class="row-editable" data-edit-url="commandes.php?edit=<?= $c['id_commande'] ?>"><td><input class="row-selector bulk-check" type="checkbox" name="selected_ids[]" value="<?= $c['id_commande'] ?>"></td><td><?= htmlspecialchars($c['date_commande']) ?></td><td><?= htmlspecialchars($c['fournisseur_nom']) ?></td><td><span class="badge yellow"><?= htmlspecialchars($c['statut']) ?></span></td><td><?= number_format($c['montant_total'],0,',',' ') ?> DJF</td></tr><?php endforeach; ?></tbody></table></form></div></div>
<?php page_end(); ?>
