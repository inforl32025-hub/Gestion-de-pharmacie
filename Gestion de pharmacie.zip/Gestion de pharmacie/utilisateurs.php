<?php
require_once __DIR__ . '/config/auth.php';
require_login();
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'save') {
        $id = (int) ($_POST['id_utilisateur'] ?? 0);
        $prenom = trim($_POST['prenom'] ?? '');
        $nom = trim($_POST['nom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $role = trim($_POST['role'] ?? 'pharmacien');
        $nom_pharmacie = trim($_POST['nom_pharmacie'] ?? '');
        $mot_de_passe = $_POST['mot_de_passe'] ?? '';
        if ($id > 0) {
            if ($mot_de_passe !== '') {
                $pdo->prepare('UPDATE utilisateurs SET prenom=?, nom=?, email=?, role=?, nom_pharmacie=?, mot_de_passe=? WHERE id_utilisateur=?')->execute([$prenom, $nom, $email, $role, $nom_pharmacie, password_hash($mot_de_passe, PASSWORD_DEFAULT), $id]);
            } else {
                $pdo->prepare('UPDATE utilisateurs SET prenom=?, nom=?, email=?, role=?, nom_pharmacie=? WHERE id_utilisateur=?')->execute([$prenom, $nom, $email, $role, $nom_pharmacie, $id]);
            }
            log_activity($pdo, 'Utilisateurs', 'Utilisateur modifié : ' . $prenom . ' ' . $nom);
            flash('success', 'Utilisateur modifié.');
        }
    }
    if (($_POST['action'] ?? '') === 'delete_selected') {
        $ids = array_map('intval', $_POST['selected_ids'] ?? []);
        $ids = array_values(array_filter($ids));
        if (!$ids) {
            flash('warning', 'Veuillez cocher au moins un utilisateur.');
        } else {
            $currentId = (int)($_SESSION['user']['id_utilisateur'] ?? 0);
            $ids = array_values(array_filter($ids, fn($id) => $id !== $currentId));
            if (!$ids) {
                flash('warning', 'Vous ne pouvez pas supprimer votre propre compte depuis cette page.');
            } else {
                $placeholders = implode(',', array_fill(0, count($ids), '?'));
                $stmt=$pdo->prepare("SELECT CONCAT(prenom, ' ', nom) AS nom_complet FROM utilisateurs WHERE id_utilisateur IN ($placeholders)");
                $stmt->execute($ids);
                $noms = $stmt->fetchAll(PDO::FETCH_COLUMN);
                $pdo->prepare("DELETE FROM utilisateurs WHERE id_utilisateur IN ($placeholders)")->execute($ids);
                log_activity($pdo, 'Utilisateurs', count($ids) . ' utilisateur(s) supprimé(s) : ' . implode(', ', $noms));
                flash('success', count($ids) . ' utilisateur(s) supprimé(s).');
            }
        }
    }
    header('Location: utilisateurs.php');
    exit;
}
$users = fetch_all_users($pdo); $edit = null; if (isset($_GET['edit'])) { $stmt = $pdo->prepare('SELECT * FROM utilisateurs WHERE id_utilisateur=?'); $stmt->execute([(int) $_GET['edit']]); $edit = $stmt->fetch(); }
page_start('Utilisateurs', 'utilisateurs');
?>
<div class="page-actions"><div class="toolbar"><button class="btn btn-danger" type="submit" form="delete-utilisateurs-form" data-confirm="Supprimer les utilisateurs cochés ?">Supprimer la sélection</button></div></div>
<div id="utilisateur-modal" class="modal <?= $edit ? 'show' : '' ?>" data-close-url="utilisateurs.php">
  <div class="modal-panel">
    <div class="modal-header"><h3>Modifier un utilisateur</h3><button class="modal-close" type="button" data-close-modal>&times;</button></div>
    <div class="modal-body"><form method="post"><input type="hidden" name="action" value="save"><input type="hidden" name="id_utilisateur" value="<?= (int)($edit['id_utilisateur'] ?? 0) ?>"><div class="form-grid"><div class="form-group"><label>Prénom</label><input name="prenom" required value="<?= htmlspecialchars($edit['prenom'] ?? '') ?>"></div><div class="form-group"><label>Nom</label><input name="nom" required value="<?= htmlspecialchars($edit['nom'] ?? '') ?>"></div></div><div class="form-grid"><div class="form-group"><label>Email</label><input type="email" name="email" required value="<?= htmlspecialchars($edit['email'] ?? '') ?>"></div><div class="form-group"><label>Rôle</label><select name="role"><option value="admin" <?= (($edit['role'] ?? '')==='admin')?'selected':'' ?>>Administrateur</option><option value="pharmacien" <?= (($edit['role'] ?? '')==='pharmacien')?'selected':'' ?>>Pharmacien</option></select></div></div><div class="form-grid"><div class="form-group"><label>Pharmacie</label><input name="nom_pharmacie" value="<?= htmlspecialchars($edit['nom_pharmacie'] ?? '') ?>"></div><div class="form-group"><label>Mot de passe (laisser vide pour conserver)</label><input type="password" name="mot_de_passe"></div></div><button class="btn btn-primary" type="submit">Enregistrer</button></form></div>
  </div>
</div>
<div class="card"><div class="card-header"><h3>Liste des utilisateurs</h3></div><div class="card-body"><div class="helper-text">Double-clique sur une ligne cochée pour modifier l'utilisateur sélectionné.</div><form method="post" id="delete-utilisateurs-form"><input type="hidden" name="action" value="delete_selected"><table><thead><tr><th><input class="bulk-check" type="checkbox" data-check-all></th><th>Nom</th><th>Email</th><th>Rôle</th><th>Pharmacie</th></tr></thead><tbody><?php foreach($users as $u): ?><tr class="row-editable" data-edit-url="utilisateurs.php?edit=<?= $u['id_utilisateur'] ?>"><td><input class="row-selector bulk-check" type="checkbox" name="selected_ids[]" value="<?= $u['id_utilisateur'] ?>"></td><td><?= htmlspecialchars($u['prenom'].' '.$u['nom']) ?></td><td><?= htmlspecialchars($u['email']) ?></td><td><span class="badge blue"><?= htmlspecialchars($u['role']) ?></span></td><td><?= htmlspecialchars($u['nom_pharmacie']) ?></td></tr><?php endforeach; ?></tbody></table></form></div></div>
<?php page_end(); ?>
